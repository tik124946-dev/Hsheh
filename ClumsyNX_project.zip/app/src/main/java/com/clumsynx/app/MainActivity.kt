package com.clumsynx.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.activity.compose.BackHandler
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

val Red = Color(0xFFE5171F)
val Bg = Color(0xFF0A0A0C)
val CardBg = Color(0xFF17171B)
val Muted = Color(0xFF9A9AA3)

class MainActivity : ComponentActivity() {
    private fun handleIntent(i: Intent?) {
        val u = i?.data ?: return
        try {
            contentResolver.openInputStream(u)?.use { Inbox.pending.value = it.readBytes().toString(Charsets.UTF_8) }
        } catch (e: Exception) { }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red, background = Bg, surface = CardBg,
                    onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White
                )
            ) { App() }
        }
    }
}

fun fmt(t: Long): String =
    if (t == 0L) "бессрочно" else SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(t))

fun vpnCmd(ctx: Context, action: String?) {
    val i = Intent(ctx, ClumsyVpnService::class.java)
    if (action != null) i.action = action
    ctx.startService(i)
}

@Composable
fun Header(sub: String = "") {
    Column(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("ClumsyNX", color = Red, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        if (sub.isNotEmpty()) Text(sub, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val st = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var role by remember { mutableStateOf("") } // "", user, dev, blocked
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(st.role == "user") }

    LaunchedEffect(Unit) {
        if (st.role == "user") {
            val err = withContext(Dispatchers.IO) { Repo.validate(st) }
            if (err == null) role = "user" else { role = "blocked"; msg = err }
            busy = false
        }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
            repeat(5) {
                Text(
                    "ClumsyNX", color = Red.copy(alpha = 0.07f), fontSize = 72.sp, fontWeight = FontWeight.ExtraBold,
                    maxLines = 1, softWrap = false, modifier = Modifier.rotate(-18f)
                )
            }
        }
        when {
            busy -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ClumsyNX", color = Red, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Text("Проверка доступа…", color = Muted)
            }
            role == "blocked" -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ClumsyNX", color = Red, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(16.dp))
                Text(msg, color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { st.role = ""; st.codeUsed = ""; role = "" }) { Text("Ввести другой код") }
            }
            role == "" -> LoginScreen(msg) { input, setErr, done ->
                scope.launch {
                    val (r, e) = withContext(Dispatchers.IO) { Repo.login(st, input) }
                    if (r.isEmpty()) { setErr(e); done(); return@launch }
                    if (r == "user") {
                        val err = withContext(Dispatchers.IO) { Repo.validate(st) }
                        if (err != null) { setErr(err); done(); return@launch }
                        st.role = "user"
                    }
                    role = r
                    done()
                }
            }
            else -> MainScreen(st, role == "dev") { st.role = ""; role = "" }
        }
    }
}

@Composable
fun LoginScreen(err: String, onLogin: (String, (String) -> Unit, () -> Unit) -> Unit) {
    var pw by remember { mutableStateOf("") }
    var e by remember { mutableStateOf(err) }
    var loading by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("ClumsyNX", color = Red, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
        Text("Введите пароль или код доступа", color = Muted)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = pw, onValueChange = { pw = it }, singleLine = true,
            label = { Text("Пароль / код") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        if (e.isNotEmpty()) Text(e, color = Red, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { loading = true; e = ""; onLogin(pw, { e = it }, { loading = false }) },
            enabled = !loading && pw.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Red),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (loading) "Проверка…" else "Войти", fontSize = 17.sp) }
        val lctx = LocalContext.current
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = { openUrl(lctx, Links.botStart("auth")) },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Авторизоваться через бота (3 дня бесплатно)", fontSize = 14.sp) }
        TextButton(onClick = { openUrl(lctx, Links.botStart("buy")) }) { Text("Купить подписку", color = Muted) }
    }
}

@Composable
fun MainScreen(st: Store, isDev: Boolean, onLogout: () -> Unit) {
    var nav by remember { mutableStateOf(1) } // 0 конфиги, 1 главная, 2 меню
    var sub by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf(-1) }
    var vals by remember { mutableStateOf(st.loadValues()) }
    var dir by remember { mutableStateOf(st.dir) }
    var cfgs by remember { mutableStateOf<List<Cfg>>(st.configs()) }
    var active by remember { mutableStateOf(st.active) }
    Params.v = vals
    Params.dir = dir
    val mctx = LocalContext.current
    LaunchedEffect(Unit) {
        if (st.fabOn && Settings.canDrawOverlays(mctx)) mctx.startForegroundService(Intent(mctx, FloatingService::class.java))
    }
    BackHandler(enabled = editing >= 0 || sub.isNotEmpty()) { if (editing >= 0) editing = -1 else sub = "" }

    fun applyCfg(nv: Map<String, Int>, nd: Int) {
        vals = nv; dir = nd
        Params.v = nv; Params.dir = nd
        st.saveValues(nv, nd)
    }
    fun setCfgs(l: List<Cfg>) { cfgs = l; st.saveConfigs(l) }
    fun install(name: String, v: Map<String, Int>) {
        applyCfg(Keys.list.associate { it.first to 0 } + v, 0)
        st.effectSec = v["auto"] ?: 0
        st.active = name; active = name
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Crossfade(targetState = nav * 10 + (if (nav == 2 && sub.isNotEmpty()) 1 else 0) + (if (nav == 0 && editing >= 0) 1 else 0), animationSpec = tween(260)) { key ->
            when (key / 10) {
                0 -> if (editing in cfgs.indices) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                        ConfigEdit(cfgs[editing], isDev, { c -> setCfgs(cfgs.mapIndexed { i, x -> if (i == editing) c else x }); editing = -1 }, { editing = -1 })
                    }
                } else {
                    ConfigsScreen(st, isDev, cfgs, active, ::setCfgs, ::install) { editing = it }
                }
                1 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    HomeTab(st, vals, active, { nav = 0 }, { nav = 2; sub = "settings" })
                }
                else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    if (sub.isEmpty()) {
                        MenuScreen(st, isDev, { sub = it }, onLogout)
                    } else {
                        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("←", fontSize = 28.sp, modifier = Modifier.clickable { sub = "" }.padding(end = 16.dp))
                            Text(
                                when (sub) { "settings" -> "Настройки"; "ai" -> "ИИ конфиги (Бета)"; "partner" -> "Партнерство"; "admin" -> "Админ"; else -> "О нас" },
                                fontSize = 22.sp, fontWeight = FontWeight.Bold
                            )
                        }
                        when (sub) {
                            "settings" -> SettingsScreen(st, vals, ::applyCfg)
                            "partner" -> PartnerScreen()
                            "ai" -> AiScreen(vals, ::install) { v -> applyCfg(vals + v, dir) }
                            "admin" -> AdminTab(st)
                            else -> Text("ClumsyNX — настройка сети: задержки, потери и пауза интернета с плавающей кнопкой. Конфиги хранятся в файлах .nx и передаются другим пользователям.", color = Muted)
                        }
                    }
                }
            }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFF111114)).padding(vertical = 6.dp)) {
            listOf("▤" to "Конфиги", "⌂" to "Главная", "☰" to "Меню").forEachIndexed { i, (ic, t) ->
                Column(
                    Modifier.weight(1f).clickable { nav = i; sub = ""; editing = -1 }.padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(ic, fontSize = 22.sp, color = if (nav == i) Red else Muted)
                    Text(t, fontSize = 11.sp, color = if (nav == i) Color.White else Muted)
                }
            }
        }
    }
}

@Composable
fun HomeTab(st: Store, vals: Map<String, Int>, activeName: String, openConfigs: () -> Unit, openSettings: () -> Unit) {
    val ctx = LocalContext.current
    val running by VpnState.running
    val paused by VpnState.paused
    var confirm by remember { mutableStateOf(false) }
    var fabOn by remember { mutableStateOf(st.fabOn) }
    val overlayOk = Settings.canDrawOverlays(ctx)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) vpnCmd(ctx, null)
    }

    fun startNow() {
        // Кнопка «Запустить» сразу показывает плавающий GUI (если выдано разрешение «Поверх других приложений»)
        if (Settings.canDrawOverlays(ctx)) {
            st.fabOn = true; fabOn = true
            ctx.startForegroundService(Intent(ctx, FloatingService::class.java))
        } else {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        val i = VpnService.prepare(ctx)
        if (i != null) launcher.launch(i) else vpnCmd(ctx, null)
    }

    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Карточка «Играть сейчас»
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = shape, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Играть сейчас", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, modifier = Modifier.weight(1f))
                    Text(
                        when { !running -> "Выключено"; paused -> "Пауза"; else -> "Работает" },
                        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(
                            when { !running -> Color(0xFF3A3A40); paused -> Red; else -> Color(0xFF1F7A3A) },
                            RoundedCornerShape(8.dp)
                        ).padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF22222A), RoundedCornerShape(12.dp))
                        .clickable { openConfigs() }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Конфиг", color = Muted, fontSize = 11.sp)
                        Text(if (activeName.isBlank()) "Не установлен" else activeName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Text("Изменить ›", color = Red, fontSize = 13.sp)
                }
                Spacer(Modifier.height(14.dp))
                if (!running) {
                    Button(
                        onClick = { confirm = true },
                        modifier = Modifier.fillMaxWidth().height(64.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F7A3A))
                    ) { Text("▶  Запустить", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                } else {
                    Button(
                        onClick = { vpnCmd(ctx, if (paused) "RESUME" else "PAUSE") },
                        modifier = Modifier.fillMaxWidth().height(64.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                    ) { Text(if (paused) "▶  Продолжить" else "❚❚  Пауза интернета", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { vpnCmd(ctx, "STOP") }, shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) { Text("Остановить ClumsyNX") }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "t.me/ClumsyNX", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                        .background(Color(0xFF2A2A31), RoundedCornerShape(10.dp))
                        .clickable { openUrl(ctx, Links.CHANNEL) }.padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }

        // Разрешения
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = shape, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("Разрешения", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Поверх других приложений", fontSize = 14.sp)
                        Text(if (overlayOk) "Выдано" else "Нужно для плавающей кнопки", color = if (overlayOk) Color(0xFF3DDC84) else Muted, fontSize = 12.sp)
                    }
                    if (!overlayOk) OutlinedButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text("Выдать", fontSize = 12.sp) }
                }
                Spacer(Modifier.height(6.dp))
                Text("VPN-разрешение Android спросит при первом запуске.", color = Muted, fontSize = 12.sp)
            }
        }

        // Плавающая кнопка
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = shape, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Плавающая кнопка", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("Квадрат с паузой/плеем поверх игры. Появляется при запуске.", color = Muted, fontSize = 12.sp)
                }
                Switch(checked = fabOn && overlayOk, onCheckedChange = { on ->
                    if (on) {
                        if (overlayOk) {
                            st.fabOn = true; fabOn = true
                            ctx.startForegroundService(Intent(ctx, FloatingService::class.java))
                        } else {
                            ctx.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    } else {
                        st.fabOn = false; fabOn = false
                        ctx.stopService(Intent(ctx, FloatingService::class.java))
                    }
                })
            }
        }

        // Целевые приложения
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = shape, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Целевые приложения", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(
                        if (st.apps.isEmpty()) "Все приложения на телефоне" else "Выбрано: ${st.apps.size}",
                        color = Muted, fontSize = 12.sp
                    )
                }
                OutlinedButton(onClick = { openSettings() }) { Text("Выбрать", fontSize = 12.sp) }
            }
        }

        val active = Keys.list.filter { (vals[it.first] ?: 0) > 0 }
        Text(
            if (active.isEmpty()) "Эффекты не заданы: трафик идёт без искажений."
            else "Сейчас настроено: " + active.joinToString(", ") { "${it.second} ${vals[it.first]}%" },
            color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Запустить ClumsyNX?") },
            text = {
                Text(
                    (if (activeName.isBlank()) "Конфиг не установлен — запуск пойдёт без эффектов. " else "Конфиг: $activeName. ") +
                        "Появится плавающая кнопка паузы."
                )
            },
            confirmButton = { TextButton(onClick = { confirm = false; startNow() }) { Text("Запустить") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Отмена") } }
        )
    }
}

@Composable
fun SettingsScreen(st: Store, vals: Map<String, Int>, apply: (Map<String, Int>, Int) -> Unit) {
    val ctx = LocalContext.current
    var smart by remember { mutableStateOf(st.smart) }
    var fab by remember { mutableStateOf(st.fabOn) }
    var fabSize by remember { mutableStateOf(st.fabSize) }
    var pauseSec by remember { mutableStateOf(st.pauseSec) }
    var effectSec by remember { mutableStateOf(st.effectSec) }
    Column(Modifier.fillMaxWidth()) {
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🛡", fontSize = 28.sp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ClumsyNX", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("  Бета", color = Color(0xFF3DDC84), fontSize = 12.sp)
                    }
                    Text(
                        "Умный режим. Автоматически выключает VPN, когда экран гаснет. Экономия заряда и производительности.",
                        color = Muted, fontSize = 13.sp
                    )
                }
                Switch(checked = smart, onCheckedChange = { smart = it; st.smart = it })
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Плавающая кнопка", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "Квадратная кнопка поверх любых приложений: нажатие — включить, пауза, продолжить; долгое нажатие — выключить. Зелёная — работает, красная — выключено или пауза. Двигай пальцем.",
                            color = Muted, fontSize = 13.sp
                        )
                    }
                    Switch(checked = fab, onCheckedChange = { on ->
                        if (on) {
                            if (!Settings.canDrawOverlays(ctx)) {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } else {
                                st.fabOn = true; fab = true
                                ctx.startForegroundService(Intent(ctx, FloatingService::class.java))
                            }
                        } else {
                            st.fabOn = false; fab = false
                            ctx.stopService(Intent(ctx, FloatingService::class.java))
                        }
                    })
                }
                Text("Размер кнопки: $fabSize", modifier = Modifier.padding(top = 8.dp))
                Slider(
                    value = fabSize.toFloat(),
                    onValueChange = { fabSize = it.roundToInt() },
                    onValueChangeFinished = {
                        st.fabSize = fabSize
                        if (fab) ctx.startForegroundService(Intent(ctx, FloatingService::class.java))
                    },
                    valueRange = 36f..120f,
                    colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red)
                )
                Text("Если включатель не сработал — разреши «Поверх других приложений» и включи снова.", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Таймеры (секунды)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Пауза: " + (if (pauseSec == 0) "пока не нажмёшь" else "$pauseSec с"), modifier = Modifier.padding(top = 8.dp))
                Text("Сколько секунд интернет стоит на паузе, потом включается сам. 0 — стоит, пока не нажмёшь «Продолжить».", color = Muted, fontSize = 12.sp)
                Slider(
                    value = pauseSec.toFloat(), onValueChange = { pauseSec = it.roundToInt() },
                    onValueChangeFinished = { st.pauseSec = pauseSec }, valueRange = 0f..300f,
                    colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red)
                )
                Text("Время работы эффектов: " + (if (effectSec == 0) "без ограничения" else "$effectSec с"))
                Text("Сколько секунд работают лаги после включения или «Продолжить», потом выключаются сами. 0 — работают постоянно.", color = Muted, fontSize = 12.sp)
                Slider(
                    value = effectSec.toFloat(), onValueChange = { effectSec = it.roundToInt() },
                    onValueChangeFinished = { st.effectSec = effectSec }, valueRange = 0f..300f,
                    colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        var advOpen by remember { mutableStateOf(false) }
        var fltOpen by remember { mutableStateOf(false) }
        BoxItem(if (advOpen) "ДЛЯ ПРОДВИНУТЫХ ▴" else "ДЛЯ ПРОДВИНУТЫХ ▾", { advOpen = !advOpen }, arrow = false)
        if (advOpen) SettingsTab(vals, apply)
        BoxItem(if (fltOpen) "Фильтры и приложения ▴" else "Фильтры и приложения ▾", { fltOpen = !fltOpen }, arrow = false)
        if (fltOpen) FiltersTab(st, vals, apply)
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Язык", fontWeight = FontWeight.Bold)
                Text("Русский", color = Muted)
                Spacer(Modifier.height(10.dp))
                Text("О приложении", fontWeight = FontWeight.Bold)
                Text("ClumsyNX 1.0", color = Muted)
            }
        }
    }
}

@Composable
fun SettingsTab(vals: Map<String, Int>, apply: (Map<String, Int>, Int) -> Unit) {
    Text(
        "Все эффекты ClumsyNX. Изменения применяются сразу, пока ClumsyNX включён на вкладке «Главная». 0% — эффект выключен. " +
            "Под каждым эффектом выбери, куда он действует: на входящие, исходящие пакеты или на оба.",
        color = Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)
    )
    Keys.list.forEach { (k, title) ->
        val v = vals[k] ?: 0
        Text("$title: $v%", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        Text(Keys.desc[k] ?: "", color = Muted, fontSize = 12.sp)
        Slider(
            value = v.toFloat(), onValueChange = { apply(vals + (k to it.roundToInt()), 0) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red)
        )
        if (k !in Keys.params) {
            val m = vals["$k.d"] ?: 3
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Оба" to 3, "Входящие" to 1, "Исходящие" to 2).forEach { (t, code) ->
                    Button(
                        onClick = { apply(vals + ("$k.d" to code), 0) },
                        modifier = Modifier.weight(1f).height(34.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (m == code) Red else CardBg, contentColor = Color.White)
                    ) { Text(t, fontSize = 11.sp, maxLines = 1) }
                }
            }
        }
    }
    Spacer(Modifier.height(16.dp))
    OutlinedButton(onClick = { apply(vals.filterKeys { it.endsWith(".d") || it == "proto" }.toMutableMap().also { m -> Keys.list.forEach { m[it.first] = 0 } }, 0) }) {
        Text("Сбросить все эффекты в 0%")
    }
}

@Composable
fun FiltersTab(st: Store, vals: Map<String, Int>, apply: (Map<String, Int>, Int) -> Unit) {
    val ctx = LocalContext.current
    var ports by remember { mutableStateOf(st.ports) }
    var chosen by remember { mutableStateOf(st.apps) }
    var apps by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var loaded by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val pr = vals["proto"] ?: 0

    Text("Фильтры", fontWeight = FontWeight.Bold, fontSize = 18.sp)
    Text("Задают, на какой трафик действуют эффекты. Остальной трафик идёт без искажений.", color = Muted, fontSize = 13.sp)

    Text("Протокол", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
    Text("UDP — игры и голос. TCP — сайты и мессенджеры. «Все» — оба.", color = Muted, fontSize = 12.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
        listOf("Все" to 0, "Только UDP" to 1, "Только TCP" to 2).forEach { (t, c) ->
            Button(
                onClick = { apply(vals + ("proto" to c), 0) }, modifier = Modifier.weight(1f).height(38.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (pr == c) Red else CardBg, contentColor = Color.White)
            ) { Text(t, fontSize = 12.sp, maxLines = 1) }
        }
    }

    Text("Порты", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
    Text("Порт сервера игры, через запятую (например 27015, 3074). Пусто — все порты. Применяется при следующем включении ClumsyNX.", color = Muted, fontSize = 12.sp)
    OutlinedTextField(
        value = ports, onValueChange = { ports = it.filter { c -> c.isDigit() || c == ',' || c == ' ' }; st.ports = ports },
        label = { Text("Порты") }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )

    Text("Приложения", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
    Text(
        "Выбери игру — тогда лаг и пауза действуют только на неё, остальные приложения работают нормально. " +
            "Ничего не выбрано — действует на весь телефон. Применяется при следующем включении ClumsyNX.",
        color = Muted, fontSize = 12.sp
    )
    OutlinedButton(
        onClick = {
            scope.launch {
                apps = withContext(Dispatchers.IO) {
                    val pm = ctx.packageManager
                    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    pm.queryIntentActivities(i, 0)
                        .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                        .filter { it.second != ctx.packageName }
                        .distinctBy { it.second }
                        .sortedBy { it.first.lowercase() }
                }
                loaded = true
            }
        },
        modifier = Modifier.padding(top = 6.dp)
    ) { Text(if (loaded) "Обновить список" else "Показать приложения") }
    Text("Выбрано: ${chosen.size}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    apps.forEach { (label, pkg) ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, fontSize = 15.sp)
                Text(pkg, color = Muted, fontSize = 11.sp)
            }
            Switch(checked = chosen.contains(pkg), onCheckedChange = { on ->
                chosen = if (on) chosen + pkg else chosen - pkg
                st.apps = chosen
            })
        }
    }
}

fun exportCfg(ctx: Context, c: Cfg) {
    val dir = java.io.File(ctx.cacheDir, "exports")
    dir.mkdirs()
    val f = java.io.File(dir, c.name.replace(Regex("[^A-Za-z0-9А-Яа-я_-]"), "_") + ".nx")
    f.writeText(c.share())
    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fp", f)
    val i = Intent(Intent.ACTION_SEND).setType("application/octet-stream")
        .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, "Экспорт конфига").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
}

@Composable
fun BoxItem(t: String, onClick: () -> Unit, color: Color = Color.White, arrow: Boolean = true) {
    val sh = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp)
            .background(Color(0xFF38383E), sh)
            .border(1.dp, Color(0x99FFFFFF), sh)
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(t, color = color, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        if (arrow) Text("›", color = color.copy(alpha = 0.7f), fontSize = 22.sp)
    }
}

@Composable
fun ConfigsScreen(
    st: Store, isDev: Boolean, list: List<Cfg>, active: String,
    setList: (List<Cfg>) -> Unit, install: (String, Map<String, Int>) -> Unit, onEdit: (Int) -> Unit
) {
    val ctx = LocalContext.current
    var tabIdx by remember { mutableStateOf(0) }
    var showNew by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<Market.Item>?>(null) }
    var mLoaded by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val t = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                val c = Cfg.parse(t)
                if (c == null) note = "Не удалось прочитать файл" else { setList(list + c); note = "Добавлено: ${c.name}" }
            } catch (e: Exception) { note = "Не удалось открыть файл" }
        }
    }
    val pending by Inbox.pending
    LaunchedEffect(pending) {
        val t = pending
        if (t != null) {
            val c = Cfg.parse(t)
            if (c == null) note = "Не удалось прочитать файл конфига" else { setList(list + c); note = "Добавлено из файла: ${c.name}" }
            Inbox.pending.value = null
        }
    }
    LaunchedEffect(tabIdx) {
        if (tabIdx == 1 && !mLoaded) {
            items = withContext(Dispatchers.IO) { Market.fetch() }
            mLoaded = true
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("Конфиги", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                listOf("Пользовательские", "Маркет").forEachIndexed { i, t ->
                    Column(Modifier.weight(1f).clickable { tabIdx = i }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(t, color = if (tabIdx == i) Color.White else Muted, modifier = Modifier.padding(8.dp))
                        Box(Modifier.fillMaxWidth().height(2.dp).background(if (tabIdx == i) Red else Color.Transparent))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            if (tabIdx == 1) {
                val mk = items
                when {
                    !mLoaded -> Text("Загрузка…", color = Muted, modifier = Modifier.padding(top = 40.dp))
                    mk == null -> Text(
                        "Маркет пока не подключён. Конфиги от разработчиков появятся здесь, как только будет запущен бот.",
                        color = Muted, modifier = Modifier.padding(top = 40.dp)
                    )
                    mk.isEmpty() -> Text("В маркете пока пусто.", color = Muted, modifier = Modifier.padding(top = 40.dp))
                    else -> mk.forEach { m ->
                        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Column(Modifier.padding(14.dp)) {
                                if (m.dev.isNotBlank()) Text(m.dev, color = Muted, fontSize = 12.sp)
                                Text(m.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                if (m.desc.isNotBlank()) Text(m.desc, color = Muted, fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                                if (m.price > 0) {
                                    Button(
                                        onClick = { openUrl(ctx, Links.botStart("buy_" + m.id)) }, modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                                    ) { Text("Купить · ${m.price} ₽") }
                                } else {
                                    Button(
                                        onClick = {
                                            val c = Cfg.parse(m.cfg)
                                            if (c != null) { setList(list + c); note = "Добавлено: ${c.name}" }
                                        }, modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                                    ) { Text("Добавить бесплатно") }
                                }
                            }
                        }
                    }
                }
                if (note.isNotEmpty()) Text(note, color = Muted, fontSize = 13.sp)
            } else {
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Импорт файла (.nx / .netcfg)") }
                if (note.isNotEmpty()) Text(note, color = Muted, fontSize = 13.sp)
                if (list.isEmpty()) {
                    Text("Конфигов еще нет, вы можете добавить их нажав на +", color = Muted, fontSize = 18.sp, modifier = Modifier.padding(top = 60.dp))
                }
                list.forEachIndexed { idx, c ->
                    val locked = !c.free && !isDev
                    Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            if (c.dev.isNotBlank()) Text(c.dev, color = Muted, fontSize = 12.sp)
                            Text((if (!c.free) "🔒 " else "") + c.name + if (active == c.name) "  ✔" else "", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            if (c.desc.isNotBlank()) Text(c.desc, color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = { install(c.name, c.v) }, modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Red)
                            ) { Text("Установить") }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                                OutlinedButton(onClick = { exportCfg(ctx, c) }, enabled = !locked, modifier = Modifier.weight(1f)) { Text("Экспорт") }
                                OutlinedButton(onClick = { onEdit(idx) }) { Text("✎") }
                                OutlinedButton(onClick = { setList(list.filterIndexed { i, _ -> i != idx }) }) { Text("🗑") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(80.dp))
            }
        }
        if (tabIdx == 0) Box(
            Modifier.align(Alignment.BottomEnd).padding(20.dp).size(58.dp).background(Red, RoundedCornerShape(18.dp)).clickable { showNew = true },
            contentAlignment = Alignment.Center
        ) { Text("+", fontSize = 30.sp, color = Color.White) }
    }

    if (showNew) {
        var n by remember { mutableStateOf("") }
        var d by remember { mutableStateOf("") }
        var ds by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("Создать конфиг") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = n, onValueChange = { n = it }, label = { Text("Название конфига") }, singleLine = true)
                    OutlinedTextField(value = d, onValueChange = { d = it }, label = { Text("Имя разработчика") }, singleLine = true)
                    OutlinedTextField(value = ds, onValueChange = { ds = it }, label = { Text("Описание конфига") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    setList(list + Cfg(n.ifBlank { "Конфиг ${list.size + 1}" }, Keys.list.associate { it.first to 0 }, 0, d, ds))
                    showNew = false
                }) { Text("Создать") }
            },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Отмена") } }
        )
    }
}

@Composable
fun ConfigEdit(c: Cfg, isDev: Boolean, onSave: (Cfg) -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf(c.name) }
    var dev by remember { mutableStateOf(c.dev) }
    var desc by remember { mutableStateOf(c.desc) }
    var v by remember { mutableStateOf(c.v) }
    var free by remember { mutableStateOf(c.free) }
    var dlg by remember { mutableStateOf("") }
    var adv by remember { mutableStateOf(false) }
    val hidden = !c.free && !isDev

    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
        Text("←", fontSize = 28.sp, modifier = Modifier.clickable { onBack() }.padding(end = 16.dp))
        Text("Редактировать", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
    Text("Основное", color = Muted)
    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название конфига") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(value = dev, onValueChange = { dev = it }, label = { Text("Имя разработчика") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Описание конфига") }, modifier = Modifier.fillMaxWidth())
    if (isDev) {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Free", fontWeight = FontWeight.Bold)
                Text("Включено — настройки конфига видны всем. Выключено — покупатель видит только название и не может смотреть настройки или делиться конфигом.", color = Muted, fontSize = 12.sp)
            }
            Switch(checked = free, onCheckedChange = { free = it })
        }
    }
    if (hidden) {
        Text("Автор скрыл настройки этого конфига.", color = Muted, modifier = Modifier.padding(top = 16.dp))
    } else {
        Text("Значения", color = Muted, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
        listOf(
            Triple("cli", "Пакеты клиента (удаление)", "%"),
            Triple("srv", "Пакеты сервера (удаление)", "%"),
            Triple("delay", "Задержка пакетов", "%"),
            Triple("loss", "Потеря пакетов", "%"),
            Triple("auto", "Автоотключение", " с")
        ).forEach { (k, t, u) ->
            BoxItem("$t: ${v[k] ?: 0}$u", { dlg = k })
        }
        BoxItem(if (adv) "ДЛЯ ПРОДВИНУТЫХ ▴" else "ДЛЯ ПРОДВИНУТЫХ ▾", { adv = !adv }, arrow = false)
        if (adv) SettingsTab(v) { nv, _ -> v = nv }
    }
    Spacer(Modifier.height(16.dp))
    Button(
        onClick = { onSave(Cfg(name.ifBlank { "Конфиг" }, v, c.dir, dev, desc, if (isDev) free else c.free)) },
        colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.fillMaxWidth().height(52.dp)
    ) { Text("Сохранить") }

    if (dlg.isNotEmpty()) {
        val key = dlg
        val max = if (key == "auto") 600f else 100f
        var x by remember(key) { mutableStateOf((v[key] ?: 0).toFloat()) }
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text(Keys.list.firstOrNull { it.first == key }?.second ?: "Автоотключение") },
            text = {
                Column {
                    Text(
                        if (key == "auto") "Секунд: ${x.roundToInt()}  (0 — не отключать)" else "Частота: ${x.roundToInt()}.0%",
                        fontWeight = FontWeight.Bold
                    )
                    Slider(
                        value = x, onValueChange = { x = it }, valueRange = 0f..max,
                        colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red)
                    )
                    Text(Keys.desc[key] ?: "Через сколько секунд после запуска эффекты выключатся сами.", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { v = v + (key to x.roundToInt()); dlg = "" }) { Text("ОК") } },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Отмена") } }
        )
    }
}

@Composable
fun MenuScreen(st: Store, isDev: Boolean, open: (String) -> Unit, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val exp = if (st.codeUsed.startsWith("CNX2.")) Security.verifyCode(st.codeUsed) else null
    val until = when {
        isDev -> "Разработчик"
        exp == null || exp == Long.MAX_VALUE -> "Никогда не истекает"
        else -> "До " + fmt(exp ?: 0L)
    }
    val sh = RoundedCornerShape(16.dp)
    Text("Меню", fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Row(
        Modifier.fillMaxWidth().padding(vertical = 12.dp).background(Color(0xFF38383E), sh)
            .border(1.dp, Color(0x99FFFFFF), sh).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("ClumsyNX", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = Color.White)
            Text("t.me/ClumsyNX", color = Color(0xFFCFCFD6), fontSize = 12.sp)
        }
        Text(until, color = Color.White, fontSize = 12.sp, modifier = Modifier.background(Color(0xFF1F7A3A), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
    }
    // Виджет разработчиков бота
    Column(
        Modifier.fillMaxWidth().padding(bottom = 6.dp).background(Color(0xFF38383E), sh)
            .border(1.dp, Red, sh).padding(16.dp)
    ) {
        Text("Разработчики бота ClumsyNX", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("Подписка, коды доступа и конфиги из маркета — в нашем Telegram-боте.", color = Color(0xFFCFCFD6), fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { openUrl(ctx, Links.botStart("buy")) }, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Red)
            ) { Text("Купить подписку", fontSize = 13.sp, maxLines = 1) }
            OutlinedButton(onClick = { openUrl(ctx, Links.CHANNEL) }, modifier = Modifier.weight(1f)) { Text("Канал", fontSize = 13.sp) }
        }
    }
    Spacer(Modifier.height(6.dp))
    BoxItem("Настройки", { open("settings") })
    BoxItem("ИИ конфиги (Бета)", { open("ai") })
    BoxItem("Партнерство", { open("partner") })
    if (isDev) BoxItem("Админ", { open("admin") })
    BoxItem("О нас", { open("about") })
    BoxItem("Выйти", onLogout, color = Red, arrow = false)
}

@Composable
fun PartnerScreen() {
    val ctx = LocalContext.current
    val sh = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF38383E), sh).border(1.dp, Color(0x99FFFFFF), sh).padding(20.dp)
    ) {
        Text("🤝", fontSize = 40.sp)
        Text("Зарабатывайте вместе с нами", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Text(
            "Если вы хотите зарабатывать вместе с нами и присоединиться к созданию конфигов, то пишите в канал, что хотите присоединиться.",
            fontSize = 16.sp, color = Color.White
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Там вы можете показать свой конфиг, и я (администратор) могу выложить его в маркет.",
            fontSize = 16.sp, color = Color.White
        )
        Spacer(Modifier.height(14.dp))
        Text("30% с продаж вашего конфига — ваши.", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF3DDC84))
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { openUrl(ctx, Links.CHANNEL) }, modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(16.dp)
        ) { Text("Написать в канал", fontSize = 16.sp) }
    }
}

@Composable
fun AiScreen(vals: Map<String, Int>, install: (String, Map<String, Int>) -> Unit, onTune: (Map<String, Int>) -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    Text(
        "Замеряет пинг, джиттер и потери твоего интернета. Это тестовый локальный алгоритм, не облачная нейросеть.",
        color = Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp)
    )
    Button(
        onClick = {
            busy = true; text = "Замеряю…"
            scope.launch {
                val r = withContext(Dispatchers.IO) { Tuner.run() }
                onTune(r.values)
                text = "Пинг ${r.avg} мс, джиттер ${r.jitter} мс, потери ${r.loss}%. Эффекты подобраны под твой интернет."
                busy = false
            }
        },
        enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Red),
        modifier = Modifier.fillMaxWidth().height(52.dp)
    ) { Text("Авто-подбор под мой интернет") }
    if (text.isNotEmpty()) Text(text, modifier = Modifier.padding(top = 10.dp))

    Text("Шаблоны для игр", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 22.dp))
    Text(
        "Это стартовые значения: проверенных публичных конфигов под эти игры я не нашёл, поэтому подбирай сам. " +
            "Применяй лаги там, где это разрешено правилами игры, иначе возможен бан аккаунта.",
        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp)
    )
    Presets.list.forEach { p ->
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text(p.desc, color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                    OutlinedButton(onClick = { install(p.name, p.v) }, modifier = Modifier.weight(1f)) { Text("Применить", fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                busy = true; text = "Замеряю…"
                                val r = withContext(Dispatchers.IO) { Tuner.run() }
                                install(p.name, Presets.scale(p.v, r.q))
                                text = "«${p.name}» подогнан под твой интернет (пинг ${r.avg} мс)."
                                busy = false
                            }
                        },
                        enabled = !busy, modifier = Modifier.weight(1f)
                    ) { Text("Под мой интернет", fontSize = 12.sp) }
                }
            }
        }
    }
}



@Composable
fun AdminTab(st: Store) {
    var sub by remember { mutableStateOf(0) }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("Коды", "Пользователи", "Маркет").forEachIndexed { i, t ->
            Button(
                onClick = { sub = i }, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = if (sub == i) Red else CardBg, contentColor = Color.White)
            ) { Text(t) }
        }
    }
    if (!Backend.enabled) {
        Text(
            "Сервер не подключён: коды и пользователи хранятся только на этом телефоне. " +
                "Чтобы они работали на всех устройствах, впиши Firebase в Config (Backend.kt).",
            color = Red, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)
        )
    }
    if (sub == 0) CodesPanel(st) else if (sub == 1) UsersPanel(st) else MarketPanel()
}

@Composable
fun CodesPanel(st: Store) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<CodeRec>()) }
    var label by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("30") }
    var maxDev by remember { mutableStateOf("1") }
    var tick by remember { mutableStateOf(0) }

    LaunchedEffect(tick) { list = withContext(Dispatchers.IO) { Repo.codes(st) } }
    fun io(block: () -> Unit) { scope.launch { withContext(Dispatchers.IO) { block() }; tick++ } }

    val ctx = LocalContext.current
    var offDays by remember { mutableStateOf("30") }
    var offLabel by remember { mutableStateOf("") }
    var offList by remember { mutableStateOf(org.json.JSONArray(st.rawGet("ocodes"))) }
    Spacer(Modifier.height(8.dp))
    Text("Подписанные коды (работают без сервера)", fontWeight = FontWeight.Bold)
    Text(
        "Такой код проверяется прямо в приложении у покупателя: подделать нельзя, срок встроен в код. " +
            "Лимит устройств и отключение для них недоступны — для этого нужны серверные коды ниже.",
        color = Muted, fontSize = 12.sp
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(value = offLabel, onValueChange = { offLabel = it }, label = { Text("Кому") }, singleLine = true, modifier = Modifier.weight(1f))
        OutlinedTextField(
            value = offDays, onValueChange = { offDays = it.filter(Char::isDigit) }, label = { Text("Дней (0 = ∞)") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
        )
    }
    Button(
        onClick = {
            val d = offDays.toIntOrNull() ?: 0
            val code = Security.makeCode(d)
            if (code != null) {
                val exp = if (d <= 0) 0L else System.currentTimeMillis() + d * 86400000L
                val a = org.json.JSONArray(st.rawGet("ocodes"))
                a.put(org.json.JSONObject().put("c", code).put("l", offLabel).put("e", exp))
                st.rawPut("ocodes", a.toString()); offList = a; offLabel = ""
            }
        },
        colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.padding(top = 8.dp)
    ) { Text("Создать подписанный код") }
    for (idx in offList.length() - 1 downTo 0) {
        val o = offList.getJSONObject(idx)
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text(o.optString("l").ifBlank { "Без названия" } + " · до " + fmt(o.optLong("e", 0)), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(o.optString("c"), color = Muted, fontSize = 10.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val sIntent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, o.optString("c"))
                        ctx.startActivity(Intent.createChooser(sIntent, "Отправить код").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text("Поделиться кодом", fontSize = 12.sp) }
                    OutlinedButton(onClick = {
                        val na = org.json.JSONArray()
                        for (j in 0 until offList.length()) if (j != idx) na.put(offList.getJSONObject(j))
                        st.rawPut("ocodes", na.toString()); offList = na
                    }) { Text("Удалить", fontSize = 12.sp, color = Red) }
                }
            }
        }
    }
    Spacer(Modifier.height(16.dp))
    Text("Серверные коды (нужен Firebase)", fontWeight = FontWeight.Bold)
    Text("Новый код", color = Muted)
    OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Кому / заметка") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = days, onValueChange = { days = it.filter(Char::isDigit) }, label = { Text("Дней (0 = ∞)") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
            value = maxDev, onValueChange = { maxDev = it.filter(Char::isDigit) }, label = { Text("Устройств") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
        )
    }
    Button(
        onClick = {
            val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            val code = (1..10).map { chars.random() }.joinToString("")
            val d = days.toLongOrNull() ?: 0L
            val exp = if (d == 0L) 0L else System.currentTimeMillis() + d * 86400000L
            val md = (maxDev.toIntOrNull() ?: 1).coerceAtLeast(1)
            io { Repo.putCode(st, CodeRec(code, label, true, exp, md, emptyList())) }
            label = ""
        },
        colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.padding(top = 8.dp)
    ) { Text("Создать код") }

    Spacer(Modifier.height(16.dp))
    Text("Коды (${list.size})", color = Muted)
    list.forEach { c ->
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.code, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        if (c.label.isNotBlank()) Text(c.label, color = Muted, fontSize = 12.sp)
                        Text("До: ${fmt(c.expires)} · устройств ${c.devices.size}/${c.maxDev}", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = c.active, onCheckedChange = { v -> io { Repo.putCode(st, c.copy(active = v)) } })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = {
                        val base = if (c.expires == 0L) System.currentTimeMillis() else maxOf(c.expires, System.currentTimeMillis())
                        io { Repo.putCode(st, c.copy(expires = base + 86400000L)) }
                    }) { Text("+1 д", fontSize = 11.sp) }
                    OutlinedButton(onClick = {
                        val base = if (c.expires == 0L) System.currentTimeMillis() else maxOf(c.expires, System.currentTimeMillis())
                        io { Repo.putCode(st, c.copy(expires = base + 30 * 86400000L)) }
                    }) { Text("+30 д", fontSize = 11.sp) }
                    OutlinedButton(onClick = { io { Repo.putCode(st, c.copy(maxDev = c.maxDev + 1)) } }) { Text("+устр.", fontSize = 11.sp) }
                    OutlinedButton(onClick = { io { Repo.putCode(st, c.copy(devices = emptyList())) } }) { Text("Сброс", fontSize = 11.sp) }
                    OutlinedButton(onClick = { io { Repo.delCode(st, c.code) } }) { Text("Удалить", fontSize = 11.sp) }
                }
            }
        }
    }
}

@Composable
fun UsersPanel(st: Store) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<UserRec>()) }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(tick) { list = withContext(Dispatchers.IO) { Repo.users(st) } }

    Spacer(Modifier.height(8.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Пользователи (${list.size})", color = Muted, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = { tick++ }) { Text("Обновить") }
    }
    list.sortedByDescending { it.lastSeen }.forEach { u ->
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(u.model.ifBlank { "Устройство" }, fontWeight = FontWeight.Bold)
                    Text("ID ${u.id} · код ${u.code.ifBlank { "—" }}", color = Muted, fontSize = 12.sp)
                    Text("Был: ${fmt(u.lastSeen)}", color = Muted, fontSize = 12.sp)
                    Text(if (u.banned) "ЗАБЛОКИРОВАН" else "активен", color = if (u.banned) Red else Color(0xFF3DDC84), fontSize = 12.sp)
                }
                Button(
                    onClick = {
                        scope.launch { withContext(Dispatchers.IO) { Repo.putUser(st, u.copy(banned = !u.banned)) }; tick++ }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (u.banned) CardBg else Red)
                ) { Text(if (u.banned) "Разбанить" else "Бан", fontSize = 12.sp) }
            }
        }
    }
}

@Composable
fun MarketPanel() {
    val ctx = LocalContext.current
    Spacer(Modifier.height(8.dp))
    Text("Маркет конфигов", fontWeight = FontWeight.Bold, fontSize = 18.sp)
    Text(
        "Выкладывать конфиги в маркет может только разработчик — через Telegram-бота. Отправь боту файл конфига (.nx или .netcfg), " +
            "напиши название, описание и цену — бот сам опубликует его во вкладке «Маркет» у всех пользователей. " +
            "Цена 0 — конфиг бесплатный. Покупатель нажимает «Купить» и оплачивает в боте.",
        color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp)
    )
    Button(
        onClick = { openUrl(ctx, Links.bot) }, colors = ButtonDefaults.buttonColors(containerColor = Red),
        modifier = Modifier.fillMaxWidth().height(52.dp)
    ) { Text("Открыть бота") }
    if (Market.URL.isBlank()) Text(
        "Маркет не подключён: впиши адрес market.json своего бота в Market.URL (Data.kt).",
        color = Red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
    )
}
